# NearbyMe — Google Play Store Deployment Guide

## Step 1: Deploy to the Web (Required First)

Your app must be live on HTTPS before you can publish to Play Store.

### Deploy to Netlify (Easiest)
1. Go to https://netlify.com and create a free account
2. Click **"Add new site" → "Deploy manually"**
3. Drag and drop the entire `nearbyme-pwa` folder
4. Your live URL: e.g. `https://nearbyme-xyz.netlify.app`

---

## Step 2: Convert PWA to Android App (TWA Method)

Use **Bubblewrap** or **PWABuilder** (easiest option below):

### Using PWABuilder (FREE, No coding needed)
1. Go to https://www.pwabuilder.com
2. Enter your live Netlify URL (e.g. `https://nearbyme-xyz.netlify.app`)
3. Click **"Start"** — it will analyze your PWA
4. Click **"Package for stores" → "Android"**
5. Download the `.apk` and `.aab` files

---

## Step 3: Create Google Play Developer Account
1. Go to https://play.google.com/console
2. Pay the one-time $25 registration fee
3. Fill in your developer profile

---

## Step 4: Publish on Google Play
1. In Play Console → **"Create app"**
2. Fill in:
   - **App name:** NearbyMe
   - **Category:** Maps & Navigation
   - **Description:** Find hospitals, pharmacies, restaurants & more near you
3. Upload the `.aab` file from PWABuilder
4. Add screenshots (take from your phone or browser)
5. Submit for review (takes 1–3 days)

---

## App Details to Fill In

| Field | Value |
|-------|-------|
| App Name | NearbyMe |
| Package ID | com.nearbyme.app |
| Category | Maps & Navigation |
| Content Rating | Everyone |
| Permissions | Location (Fine & Coarse) |
| Min Android | 7.0 (API 24) |

---

## What You Need (Checklist)
- [x] PWA with manifest.json ✅
- [x] Service Worker (offline support) ✅
- [x] HTTPS deployment ← Deploy to Netlify first
- [x] App icons (all sizes) ✅
- [ ] Google Play Developer Account ($25 one-time)
- [ ] Screenshots of the app (take on your phone)
- [ ] Short description (80 chars max)
- [ ] Full description (4000 chars max)

---

## Useful Links
- PWABuilder: https://www.pwabuilder.com
- Play Console: https://play.google.com/console
- Netlify: https://netlify.com
